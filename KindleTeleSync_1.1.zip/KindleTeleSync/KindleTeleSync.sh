#!/bin/sh

LOGFILE="/mnt/us/extensions/KindleTeleSync/sync.log"
BINARY="/mnt/us/extensions/KindleTeleSync/kindle_sync_d"

eips 30 0 "Start telesync..."

if [ -x "$BINARY" ]; then
    mkdir -p /mnt/us/books
    "$BINARY" >> "$LOGFILE" 2>&1
else
    echo "[$(date)] Ошибка: бинарник не найден или не исполняемый." >> "$LOGFILE"
fi
sleep 05
eips 30 0 "                             "